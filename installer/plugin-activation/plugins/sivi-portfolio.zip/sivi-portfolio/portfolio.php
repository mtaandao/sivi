<?php 
/**
 * Plugin Name: Sivi Portfolio
 * Description: This plugin allows you to manage, edit, and create new portfolio items in an unlimited number of portfolios.
 * Version: 1.0.0
 * Text Domain: themeplaza_portfolio
 * Domain Path: /locale/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * @package themeplaza_portfolio
 * @version 1.0.0
 * @since 1.0.0
 * @author Grig <grigpage@gmail.com>
 * @copyright Copyright (c) 2015, Themeplaza
 */
class ThemeplazaPortfolio {
	
	/**
	 * Initialization
	 * @return void
	 */
	public static function init()
	{		
		/* Set the constants needed by the plugin. */
		add_action( 'plugins_loaded', array( get_called_class(), 'constants' ), 1 );

		/* Internationalize the text strings used. */
		add_action( 'plugins_loaded', array( get_called_class(), 'i18n' ), 2 );

		/* Load the functions files. */
		add_action( 'plugins_loaded', array( get_called_class(), 'includes' ), 3 );

		/* Load the admin files. */
		add_action( 'plugins_loaded', array( get_called_class(), 'admin' ), 4 );

		/* Register activation hook. */
		register_activation_hook( __FILE__, array( get_called_class(), 'activation' ) );		
	}

	/**
	 * Defines constants used by the plugin.
	 * @return void
	 */
	public static function constants() {
		/* Set the text domain */
		define( 'THEMEPLAZAPORTFOLIO_DOMAIN', 'themeplaza_portfolio' );

		/* Set the version */
		define( 'THEMEPLAZAPORTFOLIO_VERSION', '1.0.0' );

		/* Set constant path to the plugin directory. */
		define( 'THEMEPLAZAPORTFOLIO_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );

		/* Set the constant path to the plugin directory URI. */
		define( 'THEMEPLAZAPORTFOLIO_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );

		/* Set the constant path to the includes directory. */
		define( 'THEMEPLAZAPORTFOLIO_INCLUDES', THEMEPLAZAPORTFOLIO_DIR . trailingslashit( 'includes' ) );

		/* Set the constant path to the admin directory. */
		define( 'THEMEPLAZAPORTFOLIO_ADMIN', THEMEPLAZAPORTFOLIO_DIR . trailingslashit( 'admin' ) );
	}	

	/**
	 * Loads the translation files.
	 * @return void
	 */	
	public static function i18n()
	{
		/* Load the translation of the plugin. */
		load_plugin_textdomain( THEMEPLAZAPORTFOLIO_DOMAIN, false, THEMEPLAZAPORTFOLIO_DIR . '/locale/' );
	}

	/**
	 * Loads the initial files needed by the plugin.
	 * @return void
	 */
	public static function includes() {
		foreach ( glob( THEMEPLAZAPORTFOLIO_INCLUDES . "*.php" ) as $file ) {
		    require_once $file;
		}
	}

	/**
	 * Loads the admin functions and files.
	 * @return void
	 */
	public static function admin() {
		if ( is_admin() ) {
			foreach ( glob( THEMEPLAZAPORTFOLIO_ADMIN . "*.php" ) as $file ) {
		    	require_once $file;
			}	
		}
	}

	/**
	 * Method that runs only when the plugin is activated.
	 * @return void
	 */
	public static function activation() {
		/* Get the administrator role. */
		$role = get_role( 'administrator' );

		// /* If the administrator role exists, add required capabilities for the plugin. */
		if ( !empty( $role ) ) {

			$role->add_cap( 'read_portfolio_items' );
			$role->add_cap( 'delete_portfolio_items' );
			$role->add_cap( 'edit_portfolio_items' );
		}
	}
}

ThemeplazaPortfolio::init();